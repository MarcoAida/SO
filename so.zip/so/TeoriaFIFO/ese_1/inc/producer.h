#ifndef _PRODUCER_HH
#define _PRODUCER_HH

void producer (int *pipeFD, const char *filename);

#endif
