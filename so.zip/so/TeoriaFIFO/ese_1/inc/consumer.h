#ifndef _CONSUMER_HH
#define _CONSUMER_HH

void consumer (int *pipeFD);

#endif
