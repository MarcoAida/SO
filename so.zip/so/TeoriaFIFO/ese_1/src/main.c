#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>


#define LEN 20
#define DIM 2

int main(){
  int a[DIM];
  //mkfifo();
  int fd = open("laFifo", O_RDONLY);

  // reading bytes from fifo
  char buffer[LEN];
  printf("Aperta fifo\n");
  read(fd, buffer, LEN);
  scanf("%s", a[0]);
  scanf("%s", a[1]);

    if(a[0] >= a[1])
        printf("a maggiore o uguale b.\n");

    if(a[0] < a[1])
        printf("a minore di b.\n");

  // Printing buffer on stdout
  printf("%s\n", buffer);
  //write(fd, buffer, LEN);

  // closing the fifo
  close(fd);

  return 0;
}
