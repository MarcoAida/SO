//bash: man -k pthread

#include <pthread.h>
#include <stdio.h>

#define N 10

//semafori
pthread_mutex_t m1;
pthread_mutex_t m2;


void * t1(void * arg){
    int i;
    for(i = 1; i < N; i ++){
        pthread_mutex_lock(&m1);
        printf("T1 %ld\n", pthread_self());
        pthread_mutex_unlock(&m2);
    }
    pthread_exit(NULL);
}


void * t2(void * arg){
    int i;
    for(i = 1; i < N; i ++){
        pthread_mutex_lock(&m2);
        printf("T2 %ld\n", pthread_self());
        pthread_mutex_unlock(&m1);
    }
    pthread_exit(NULL);
}

int main(){

    pthread_t tid1, tid2;
    int test;
    void ** status = NULL;
    
    pthread_mutex_init(&m1, NULL);
    pthread_mutex_init(&m2, NULL);
    pthread_mutex_lock(&m2);
    
    test = pthread_create(&tid1, PTHREAD_CREATE_JOINABLE, t1, NULL);
    
    if(test != 0){
        printf("Error oper, error = %d \n", test);
    }
    
    test = pthread_create(&tid2, PTHREAD_CREATE_JOINABLE, t2, NULL);
    
    if(test != 0){
        printf("Error oper, error = %d \n", test);
    }
    
    /* anche commentate */
    pthread_join(tid1, status);
    pthread_join(tid2, status);
    
    printf("main %ld\n", pthread_self());
    
    /* anche decommentato */
    //pthread_mutex_unlock(&m1);
    
    pthread_exit(NULL);
    
    return 0;
}
