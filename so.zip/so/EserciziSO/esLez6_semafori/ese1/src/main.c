#include "errExit.h"
#include "semaphore.h"

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>

void printSemValue(int semid){
    unsigned short semVal = 4;
    union semun arg;
    arg.array = semVal;

    if(semctl(semid, 0, GETALL, arg) == -1){
        errExit("semctl error");
    }

    prinntf("semaphore set state:\n");
    for(int i = 0; i < 4; i ++)
        printf("%d", semVal[i]);
}

char message[] = {"C", "B", "A", "done"};

int main(){
    
    int semid = semget(IPC_PRIVATE, 4, S_IRUSR | S_IWUSR);
    
    if(semid == -1)
        errExit("semid error");
    
    unsigned short semIntVal[] = {0, 0, 1, 3};
    union semun arg;
    arg.array = semIntVal;

    if(semctl(semid, 0 /*ignored*/, SETALL, arg) == -1)
        errExit("semid error");

    printSemValue(semid);

    for(int child = 0; child < 3; child ++){
        pid_t pid = fork();

        if(pid == -1)
            printf("child %d not create", child);
        else if(pid == 0){
            //wait i-th sem
            semOp(semid, (unsigned short)child, -1);
            
            printf("%s\n", message[child]);
            //flush
            flush(stdout);

            //decrement
            semOp(semid, 3, -1);

            //unlock (i-1)-th sem
            if(child > 0)
                semOp(semid, (unsigned short)(child - 1), 1);
            

            printf("Done!\n");
            
            exit(0);
        }
    }
        
    return 0;
}