#include<stdio.h>
#include<stdlib.h>

#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<unistd.h>

//#include "errExit.h"

#define BUFFER_SZ 100
char buffer[BUFFER_SZ + 1];

int main(int argc, char *argv[]){
    // for each file provided as input argument
	for(int i = 1; i < argc; ++i){
        // open the file in read only mode 
        int file = open(argv[i], O_RDONLY);
        if(file == -1){
            printf("File %s does not exist\n", argv[i]);
            continue;
        }

        ssize_t bR = 0;

        do{
            //read the file in chunks
            bR = read(file, buffer, BUFFER_SZ);
            if(bR > 0){
                // add the charactere '\0' to let print know where a string ends
                buffer[bR] = '\0';
                printf("%s", buffer);
            }
        }while(bR > 0);

        // close the file descriptor
        close(file);
    }

	return 0;
}