To compile:

> gcc main.c -o ese_1
> cd ese_1

> make


To run the executable:

> ./'file rinominato nel makefile in prima riga/..' (+ ...)


To Remove object file(s) and executable(s):

> make clean
