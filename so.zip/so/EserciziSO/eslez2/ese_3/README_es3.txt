>arrivo alla directory da cui lavorare

>make clean

>make

>'lancio il nome del file rinominato nel Makefile'
(eses: ./search_replace file1 file1_modified e f)
primo carattere (e) sostituito con il secondo carattere (f)

> cat file1_modified (per vedere il risultato
