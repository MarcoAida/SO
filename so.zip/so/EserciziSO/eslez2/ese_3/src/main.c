#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "errExit.h"

int main (int argc, char *argv[]) {
    char *charSearch, *charReplace;
    char *fileSource, *fileDestination;

    if(argc != 5){
        printf("Usage:  <sourcefile> <destinaition> <char search> <char replace>\n");
        return 1;
    }else{
        fileSource = argv[1];
        fileDestination = argv[2];
        charSearch = argv[3];
        charReplace = argv[4];
    }

    //open the source file in read only mode
    int fileS = open(fileSource, O_RDONLY);

    if(fileS == -1){ //il file non esiste
        printf("file %s does not exist\n", fileSource);
        errExit("source open failed");
    }

    int fileD = -1;

    //check if destination file already exist
    if(access(fileDestination, F_OK) == 0){
        printf("il file %s gia' esiste\n", fileDestination);
        return -1;
    }

    //create and open the destination file fro only writing
    fileD = open(fileDestination, O_CREAT | O_EXCL | O_WRONLY, S_IRUSR | S_IWUSR);
    
    //if fileD is = -1, then something went wrong with the open system call
    if (fileD == -1)
        errExit("open failed");
    
    //start copying
    ssize_t bR;
    char c;

    do{
        bR = read(fileS, &c, sizeof(char));

        if(bR == -1)
            errExit("read failed");
        if(c == *charSearch)
            c = *charReplace;
        
        //check if write complited successfully
        if(bR > 0 && write(fileD, &c, sizeof(char)) != sizeof(char))
            errExit("write failed");
        
    }while(bR > 0);

    //close file descriptor

    if(close(fileS) == -1 || close(fileD) == -1){
        errExit("close failed");
    }


    return 0;
}
