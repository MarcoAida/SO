#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>

int main(){
    int shmid;
    int *val;
    
    shmid = shmget(101, sizeof(int) * 10, 0600);

    printf("shmid = %d\n", shmid);
    
    val =  (int *) shmat(shmid, NULL, SHM_RND);
    
    //*val = *val * 2;  //
    
    printf("Valore memorizzato = %d\n", val[0]);
    printf("Valore memorizzato = %d\n", val[1]);
    
    shmdt(val);

    shmctl(shmid, IPC_RMID, NULL);
    
    return 0;
}
