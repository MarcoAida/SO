#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>

int main(){
    int shmid;
    int *val;
    
    shmid = shmget(101, sizeof(int) * 10, IPC_CREAT | 0600);

    printf("shmid = %d\n", shmid);
    
    val =  (int *) shmat(shmid, NULL, SHM_RND);
    
    //*val = 27;
    val[0] = 27;
    val[1] = 13;
    val[2] = 11;
    
    shmdt(val);

    return 0;
}
