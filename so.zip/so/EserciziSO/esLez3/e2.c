#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>

void child_process(int id) {
    printf("Sono il processo figlio con PID %d. Il PID del mio processo padre è %d.\n", getpid(), getppid());

    // Genera un numero casuale tra 0 e 255 come codice di terminazione
    int exit_code = rand() % 256;
    printf("Processo figlio %d terminato con codice %d.\n", id, exit_code);

    // Termina il processo figlio con il codice generato casualmente
    exit(exit_code);
}

int main(int argc, char *argv[]) {
    int n;
    scanf("%d", &n);

    // Crea N processi figlio
    for (int i = 1; i <= n; i++) {
        pid_t pid = fork();

        if (pid < 0) {
            perror("Errore nella creazione del processo figlio");
            return 1;
        } else if (pid == 0) {
            // Codice eseguito dal processo figlio
            child_process(i);
        }
    }

    // Codice eseguito dal processo padre
    for (int i = 1; i <= n; i++) {
        // Attende che ogni processo figlio termini e ne ottiene il codice di uscita
        int status;
        pid_t terminated_pid = wait(&status);
        printf("Processo padre: Figlio con PID %d terminato con codice %d.\n\n", terminated_pid, WEXITSTATUS(status));
    }

    return 0;
}