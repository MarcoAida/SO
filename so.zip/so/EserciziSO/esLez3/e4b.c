#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>

int main() {
    // Genera due numeri casuali
    srand(time(0));

    int num1 = (int) (((double) rand() / RAND_MAX) * MAX_NUM);
    int num2 = (int) (((double) rand() / RAND_MAX) * MAX_NUM);

    // Converte i numeri casuali in stringhe per passarli come argomenti al programma a)
    char num1_str[100];
    char num2_str[100];

    sprintf(num1_str, "%d", num1);
    sprintf(num2_str, "%d", num2);

    // Utilizza exec per eseguire il programma a) con i numeri casuali come argomenti
    execl("./e4", "./e4", num1_str, num2_str, (char *) NULL);

    // Se exec ha successo, il codice successivo non verrà eseguito
    perror("Errore nell'esecuzione di exec");

    return 1;
}