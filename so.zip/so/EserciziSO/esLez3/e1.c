#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>

extern char **environ;

int main(int argc, char *argv[], char *env[]) {
    char *user = getenv("USER");
    char *home = getenv("HOME");

    if (user != NULL) {
        printf("USERNAME: %s\n", user);
    } else {
        printf("USERNAME non trovato nell'ambiente.\n");
    }

    if (home != NULL) {
        printf("HOME: %s\n", home);
    } else {
        printf("HOME non trovato nell'ambiente.\n");
    }

    char cwd[256];
    if (getcwd(cwd, sizeof(cwd)) == NULL) {
        perror("Errore nell'ottenere il percorso della directory di lavoro");
        return 1;
    }
    
    // Ottieni il percorso della home directory dell'utente

    if (home == NULL) {
        fprintf(stderr, "Variabile HOME non trovata nell'ambiente.\n");
        return 1;
    }

    // Confronta i percorsi
    if (strcmp(cwd, home) != 0) {
        // La directory di lavoro attuale non è una sotto directory della home directory dell'utente

        // Imposta la home directory dell'utente come directory di lavoro
        if (chdir(home) != 0) {
            perror("Errore nel cambiare la directory di lavoro");
            return 1;
        }

        // Crea una directory "test" se non esiste
        if (mkdir("test", 0700) != 0) {
            perror("Errore nella creazione della directory");
            return 1;
        }

        // Apre un file di testo vuoto in modalità scrittura
        FILE *file = fopen("test/file.txt", "w");
        if (file == NULL) {
            perror("Errore nell'apertura del file");
            return 1;
        }
        fclose(file);

        // Stampa il messaggio
        char *user = getenv("USER");
        printf("Caro %s, sono dentro la tua home!\n", user);
    } else {
        printf("La directory di lavoro attuale è già la home directory dell'utente.\n");
    }

    return 0;
}