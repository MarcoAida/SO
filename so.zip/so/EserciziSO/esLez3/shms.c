#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>

int main(){
    int shmid;
    shmid = shmget(101, 48, IPC_CREAT | 0600);

    printf("shmid = %d", shmid);

    return 0;
}
