#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define DIM 10

#define MAX_THREADS 5

struct ThreadData{
    int start;
    int end;
    long long partialSum;
    int *array;
};

void *sum(void *arg){
    struct ThreadData *threadData = (struct ThreadData *) arg;

    threadData ->  partialSum = 0;

    for(int i = threadData ->  start; i <= threadData ->  end; i ++){
        threadData ->  partialSum += threadData -> array[i];
    }

    return NULL;
}

int main() {
    int array[DIM];

    for(int i = 0; i < DIM; i ++)
        array[i] = i + 1;

    for(int i = 0; i < DIM; i ++)
        printf("%d  ", array[i]);

    printf("\n\n");

    int numThreads;
    printf("Enter the number of threads: \n");
    scanf("%d", &numThreads);

    if(numThreads > MAX_THREADS || numThreads > DIM || numThreads < 1){
        printf("Error: number of threads excedes the maximum allowed or array size");
        return 1;
    }

    //create an array of threads
    pthread_t threads[MAX_THREADS];

    //create an array to hold thread data
    struct ThreadData threadData[MAX_THREADS];

    //calculate the range of array elements that each thread ill sum
    int elementsPerThread = MAX_THREADS / numThreads;
    int remainingElements = MAX_THREADS % numThreads;

    int start = 0;

    //Create threads and assigning tasks for each thread
    for(int i = 0; i < numThreads; i ++){
        threadData[i].start = start;
        threadData[i].end = start + elementsPerThread - 1;

        if(i < remainingElements)
            threadData[i].end ++;   //distribute remaining elements

        threadData[i].array = array;    //pass the pointer

        //Create the threadand execute partialSum
        if(pthread_create(&threads[i], NULL, sum, (void *)&threadData[i]) != 0){
            fprintf(stderr, "Error creating thread %d\n", i);
            return 1;
        }

        //move to the next range for the next thread
        start = threadData[i].end + 1;
    }

    //wait for all threads finish
    for(int i = 0; i < numThreads; i ++){
        pthread_join(threads[i], NULL);
    }
    
    //calculate the final sum

    long long finalSum = 0;

    for(int i = 0; i < numThreads; i ++){
        finalSum += threadData[i].partialSum;
    }

    printf("Sum of the array elements: %lld \n", finalSum);

    return 0;
}