#include <stdio.h>

int fibonacciRicorsivo(int n){
    if(n <= 1)
        return n;
    else 
        return fibonacciRicorsivo(n - 1)+ fibonacciRicorsivo(n - 2);
}

int main() {

    int n;

    printf("enter the number of terms in the fibonacci series:\n");
    scanf("%d", &n);

    if(n < 0){
        //error
        return 1;
    }

    int f = fibonacciRicorsivo(n);

    return 0;
}