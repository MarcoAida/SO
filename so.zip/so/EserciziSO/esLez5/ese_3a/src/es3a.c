#include <stdio.h>

void fibonacciIterative(int n){
    int prev = 0;
    int current = 1;
    int next;

    printf("Fibonacci series up to the term: \n");

    for(int i = 0; i < n; i ++){
        printf("%d ", prev);
        next = prev + current;
        prev = current;
        current = next;
    }
    printf("\n");
}

int main() {

    int n;

    printf("enter the number of terms in the fibonacci series:\n");
    scanf("%d", &n);

    if(n < 0){
        //error
        return 1;
    }

    fibonacciIterative(n);

    return 0;
}