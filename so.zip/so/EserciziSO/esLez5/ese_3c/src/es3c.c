#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>

#define MAX_PROCESSES 10
#define MAX_SEQUENCE 100

typedef struct {
    int start;
    int end;
    unsigned long long *result;
    int sem_id;
    int processes_num;
}ProcessesInfo;

unsigned long long fibonacci(int n){
    if(n <= 1)
        return n;
    else
        return fibonacci(n - 1) + fibonacci(n - 2);
}

//define semaphore operation structures
struct sembuf sem_lock = {0, -1, 0}; //lock
struct sembuf sem_unlock = {0, 1, 0}; //unlock

//function executedby each process
void calculateFibonacci(ProcessesInfo *info){
    for(int i = info -> start; i <= info -> end; i ++){
        unsigned long long fib = fibonacci(i);
        
        semop(info -> sem_id, &sem_lock, 1); //lock semaphore

        info -> result[i] = fib;

        printf("Process %d: calculateFibonacci(%d) = &llu\n", info-> process, i, info->result);
        
        semop(info -> sem_id, &sem_unlock, 1) //unlock semaphore
    }

    exit(0);
}

int main() {

    int numProcesses, sequenceLength;

    printf("Enter the number od processes (1 - %d)\n", MAX_PROCESSES);
    scanf("%d", &numProcesses);

    //check 
    printf("Enter the length of the fibonacci sequence(1 - %d)\n", MAX_SEQUENCE);
    scanf("%d", &sequenceLength);

    //create shared memory for result array
    int shm_id = shmget(IPC_PRIVATE, sequenceLength * sizeof(unsigned long long), IPC_CREAT | 0666);
    unsigned long long *result = shmat(shm_id, NULL, 0);
    
    //create semaphore
    int sem_id = semget(IPC_CREATE, 1, IPC_CREAT | 0666);
    semctl(sem_id, 0, SETVAL, 1);

    pid t pids[MAX_PROCESSES];
    ProcessesInfo processesInfo[MAX_PROCESSES];

    //calculate the range of fibonacci numbers for each process
    int elementsPerProcess = sequenceLength / numProcesses;
    int remainingElements = sequenceLength % numProcesses;
    int start = 0;
    
    //create process and assign tacks
    for(int i = 0; i < numProcesses; i ++){
        processesInfo[i].start = start;
        processesInfo[i].end = start + elementsPerProcess -1 + (i < remainingElements ? 0 : 1);
        start = processesInfo[i].end + 1;
        processesInfo[i].result = result;
        processesInfo[i].sem_id = sem_id;
        processesInfo[i].processes_num = i + 1;

        pids[i] = fork();

        if(pids[i] == 0){
            //calculate process
            calculateFibonacci(&processesInfo[i]);
        }
    }

    for(int i = 0; i < numProcesses; i ++){
        waitpid(pids[i], NULL, 0);
    }

    printf("\nFibonacci sequence: \n");
    for(int i = 0; i < sequenceLength; i ++){
       printf("%llu ", result[i]);
    }

    printf("\n");

    //clean up
    shmdt(result);

    shmctl(shm_id, IPC_RMID, NULL);

    semctl(sem_id, 0, IPC_RMID);
    

    return 0;
}