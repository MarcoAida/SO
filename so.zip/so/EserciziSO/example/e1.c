#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

extern char environ;

int main (int argc, char *argv[]) {
    char *user[10], *home[10];

    for(char **it = environ; (*it) != NULL; ++it){
        //while((*it) != 'USERNAME')
            *user = (*it);
        //while((*it) != 'HOME')
            *home = (*it);
        printf("--> %s \n", *user);
        printf("--> %s \n", *home);   
    }

    return 0;
}