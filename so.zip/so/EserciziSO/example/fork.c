#include <stdio.h>
#include <unistd.h>

int main(int argc, char *argv[]){
    int p0;
    int p1;

    p0 = fork();    //figlio
    p1 = fork();    //figlio

    //pid_t fork(void);
    pid_t getppid(void); //ottiene il processo id del padre

    //se il processo padre muore viene ereditato da init (processo 1) s


    return 0;
}