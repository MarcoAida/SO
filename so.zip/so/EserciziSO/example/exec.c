#include <stdio.h>
#include <unistd.h>

int main(int argc, char *argv[]){
    //l' exec non modifica i file aperti
    //se l'exec va a buon fine quello che viene prima e dopo non viene eseguito

    //execl("/usr/bin/ls", "ls", "-al", NULL);  //senza p : path
    execlp("ls", "ls", "-al", NULL);  //con path

    return 0;
}