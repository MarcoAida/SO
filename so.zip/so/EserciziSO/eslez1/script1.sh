#!/bin/bash

temperature_values=`tail +2 Occupancy.csv | cut -d',' -f2`
humidity_values=`tail +2 Occupancy.csv | cut -d',' -f3`
light_values=`tail +2 Occupancy.csv | cut -d',' -f4`
co2_values=`tail +2 Occupancy.csv | cut -d',' -f5`
#echo $temperature_values

t_value=0
h_value=0
l_value=0
c_value=0

for i in $temperature_values
do
	if [ $i -gt $t_value ]; then
		t_value=$i
	fi
done

for i in $humidity_values
do
	if [ $i -gt $h_value ]; then
		h_value=$i
	fi
done

for i in $light_values
do
	if [ $i -gt $l_value ]; then
		l_value=$i
	fi
done

for i in $co2_values
do
	if [ $i -gt $c_value ]; then
		c_value=$i
	fi
done

echo $t_value
echo $h_value
echo $l_value
echo $c_value
