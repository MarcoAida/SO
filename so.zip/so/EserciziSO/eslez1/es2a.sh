#!/bin/bash

#echo(`totale per ogni valore`)
cat Occupancy.csv | tail +1 | cut -d',' -f2 | less | sort -rn | head -n1
cat Occupancy.csv | tail +1 | cut -d',' -f3 | less | sort -rn | head -n1
cat Occupancy.csv | tail +1 | cut -d',' -f4 | less | sort -rn | head -n1
cat Occupancy.csv | tail +1 | cut -d',' -f5 | less | sort -rn | head -n1

DA RISOLVERE

#echo(`massimo per ogni valore`)
cat Occupancy.csv | tail +1 | cut -d',' -f2 | sort | head -n1
cat Occupancy.csv | tail +1 | cut -d',' -f3 | sort | head -n1
cat Occupancy.csv | tail +1 | cut -d',' -f4 | sort | head -n1
cat Occupancy.csv | tail +1 | cut -d',' -f5 | sort | head -n1

#echo(`minimo per ogni valore`)
cat Occupancy.csv | tail +1 | cut -d',' -f2 | head
cat Occupancy.csv | tail +1 | cut -d',' -f3 | head
cat Occupancy.csv | tail +1 | cut -d',' -f4 | head
cat Occupancy.csv | tail +1 | cut -d',' -f5 | head
