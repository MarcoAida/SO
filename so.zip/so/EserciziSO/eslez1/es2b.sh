#!/bin/bash

values_true=`grep ".*,.*,.*,.*,.*,0" Occupancy.csv`
values_false=`grep ".*,.*,.*,.*,.*,1" Occupancy.csv`

echo $values_true
echo $values_false

echo $values_true | tr ' ' '\n' | wc -l
echo $values_false | tr ' ' '\n' | wc -l
