#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<stdio.h>
#include<unistd.h>

int main(){
	int fd;
	char c;
	char s[1024];
	int n;
	fd = open("nuovofile.txt", O_RDONLY);
	
	while(n > 0){
	    n = read(fd, s, 1024);
	    write(1, s, n);
	    //printf("n = %d \n", n);
	    //printf("%c\n", c);
	}
	
	//s[n] = '\0';
	//printf("%c\n", s);	
	
	
	return 0;
}
