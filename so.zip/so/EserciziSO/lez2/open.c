#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat>
#include<stdio.h>
#include<unistd.h>

int main(){
	//open("nuovofile.txt", O_CREATE | O_TRUNCATE, 0644);
	
	fd = open("nuovofile.txt", O_WRONLY);
	
	//le system call vengono stampate prima (\n una di quelle)
	printf("fd = %d \n", fd);
	
	//write(fd, "ciao\n", 5);
	write(1, "ciao\n", 5);
		
	return 0;
}
