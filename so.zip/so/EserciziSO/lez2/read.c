#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat>
#include<stdio.h>
#include<unistd.h>

int main(){
	int fd;
	//open("nuovofile.txt", O_CREATE | O_TRUNCATE, 0644);
	char s[1024];
	int n;
	fd = open("nuovofile.txt", O_RDONLY);
	
	n = read(fd, s, 1024);
	write(1, s, n);
	printf("n = %d \n", n);
	
	s[n] = '\0';
	printf("%s\n", s);	
	
	
	return 0;
}
