#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

#define NUM_THREADS 4

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
int current_thread = 0;
int num_times;

char *message[] = {"Corso", "Di", "Sistemi", "Operativi\n"};

void *thread_function(void *arg){
    int thread_num = *((int *) arg);    //deferenziazione
    free(arg);

    //loop to print messages
    for(int i = 0; i < num_times; i ++){
        pthread_mutex_lock(&mutex);

        while (current_thread != thread_num)
        {
            pthread_cond_wait(&cond, &mutex);
        }

        printf("%s", message[thread_num]);
        fflush(stdout);

        current_thread = (current_thread + 1) % NUM_THREADS;

        pthread_cond_broadcast(&cond);
        pthread_mutex_unlock(&mutex);
    }

    return NULL;
}

int main(int argc, char *argv[]){
    
    if(argc != 2)
        printf("Usage: %s <number_times>\n", argv[0]);
    
    num_times = atoi(argv[1]);

    pthread_t threads[NUM_THREADS];

    int *thread_ids[NUM_THREADS];

    for(int i = 0; i < NUM_THREADS; i ++){
        thread_ids[i] = malloc(sizeof(int));
        *thread_ids[i] = i;

        if(pthread_create(&threads[i], NULL, thread_function, thread_ids[i]) != 0){
            perror("pthread_create failed");
            exit(EXIT_FAILURE);
        }
    }

    for(int i = 0; i < NUM_THREADS; i ++){
        if(pthread_join(threads[i], NULL) != 0){
            perror("pthread_join failure");
        }
    }
    
    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&cond);

    printf("Done!\n");
 
    return 0;
}
