#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>

int main(){    
    int fd;
    fd = semget(101, 3, IPC_CREAT | 0640);
    if(fd < 0)
        printf("Errore creazione del semaforo\n");
    
    semctl(fd, 0, IPC_RMID, NULL);

    return 0;
}
