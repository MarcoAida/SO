#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>

//prima deve eseistere il semaforo semget.c

int main(){
    int fd;
    fd = semget(101, 3, 0640);
    
    int rsop;
    
    if(fd < 0)
        printf("Errore creazione del semaforo\n");
    
    struct sembuf op[3];
    op[0].sem_num = 1; //0
    op[0].sem_op = -1;
    op[0].sem_flg = 0;
    
    op[1].sem_num = 0;
    op[1].sem_op = -1; //1
    op[1].sem_flg = 0;
    
   /* op[0].sem_num = 0;
    op[0].sem_op = -1;
    op[0].sem_flg = 0;
    */
    rsop = semop(fd, op, 2);    //3° argomento numero delle operazioni dei semafori creati

    if(rsop < 0)
        printf("Errore semop\n");
    
    return 0;
}
