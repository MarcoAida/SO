#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>

int main(){
    int fd;
    fd = semget(101, 3, 0640);
    
    int rsop;
    
    if(fd < 0)
        printf("Errore creazione del semaforo\n");
     
    struct sembuf op;
    op.sem_num = 0;
    op.sem_op = -1; //-2 -5 -46
    op.sem_flg = 0;
    
    rsop = semop(fd, &op, 1);

    if(rsop < 0)
        printf("Errore semop\n");
        
    return 0;
}
