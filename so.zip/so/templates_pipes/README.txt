To compile:
> cd ese_1
> make


To run the executable
> ./ese_1 ...


To Remove object file(s) and executable(s)
> make clean
