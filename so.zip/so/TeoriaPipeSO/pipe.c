#include <unistd.h>
#include <stdio.h>

int main(){
    
    int fd[2];
    char c;
    int pid;
    int r;
    
    pipe(fd);
    pid = fork();
    
    if(pid > 0){    // padre
        close(fd[1]);   //importante
    
        while((r = read(fd[0], &c, 1)) > 0){
            write(1, &c, r);
        }
        
    }
    else{    // figlio
        close(fd[0]);
        
        close(1);
        dup(fd[1]);
        close(fd[1]);
        
        execlp("ls", "ls", "-al", NULL);
        // write(fd[1], "X", 1);
    }
    
    printf("fdpipe = %d %d\n", fd[0], fd[1]);
    
    return 0;
}

