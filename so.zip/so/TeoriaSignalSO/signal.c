// ps fax | grep a (a.out) eseguibile

// kill -9 <pid> (pid processo da killare)


#include <signal.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>


void fSegnale(int seganle){
    //printf(" E' stato premuto ^C\n");
    printf(" E' stato premuto il segnale %d\n", segnale);
    if(segnale == 2)
        signal (2, SIG_DFL);    //default
    if(segnale == 10)
        signal (10, SIG_IGN);
}

int main(){

    signal(2, fSegnale);    //system call
    signal(10, fSegnale);
    signal(14, fSegnale);
    alarm(5);   //senza per fare il while
    
    printf("Inizio del ciclo infinito, il mio pid e': %d\n", getpid());
    pause();
    
    // while(1);    //sensa alarm e pause
    
    printf("THE END");
    
    return 0;
}

